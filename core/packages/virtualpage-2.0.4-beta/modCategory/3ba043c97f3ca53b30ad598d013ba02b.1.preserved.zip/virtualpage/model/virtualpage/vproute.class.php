<?php

class vpRoute extends xPDOSimpleObject
{
}