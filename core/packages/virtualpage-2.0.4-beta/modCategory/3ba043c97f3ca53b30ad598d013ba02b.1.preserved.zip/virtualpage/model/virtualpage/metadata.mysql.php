<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'vpRoute',
    1 => 'vpHandler',
    2 => 'vpEvent',
  ),
);