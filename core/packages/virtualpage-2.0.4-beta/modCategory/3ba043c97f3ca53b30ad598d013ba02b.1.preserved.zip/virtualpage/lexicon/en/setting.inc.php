<?php

$_lang['area_virtualpage_main'] = 'Основные';

$_lang['setting_virtualpage_active'] = 'Включить / Выключить VirtualPage';

$_lang['setting_virtualpage_fastrouter_key'] = 'Ключ Fast Router';
$_lang['setting_virtualpage_fastrouter_key_desc'] = 'Ключ в массиве $_REQUEST';

$_lang['setting_virtualpage_exclude_event_groupname'] = 'Исключить события';
$_lang['setting_virtualpage_exclude_event_groupname_desc'] = 'Имена групп событий. Входящие в группу события будут исключены. ';

$_lang['setting_virtualpage_prefix_placeholder'] = 'Префикс плейсходеров';
$_lang['setting_virtualpage_prefix_placeholder_desc'] = 'Префикс плейсходеров в обработчике. По умолчанию "vp."';