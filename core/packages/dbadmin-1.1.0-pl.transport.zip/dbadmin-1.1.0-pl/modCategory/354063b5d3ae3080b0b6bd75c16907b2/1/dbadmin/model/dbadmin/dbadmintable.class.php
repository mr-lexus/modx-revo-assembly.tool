<?php
class dbAdminTable extends xPDOObject {}