<?php

$_lang['modupdater_prop_limit'] = 'The number of Links to limit per page.';
$_lang['modupdater_prop_outputSeparator'] = 'A string to separate each row with.';
$_lang['modupdater_prop_sortBy'] = 'The field to sort by.';
$_lang['modupdater_prop_sortDir'] = 'The direction to sort by.';
$_lang['modupdater_prop_tpl'] = 'The chunk to use for each row of Links.';
$_lang['modupdater_prop_toPlaceholder'] = 'If set, will output the content to the placeholder specified in this property, rather than outputting the content directly.';
