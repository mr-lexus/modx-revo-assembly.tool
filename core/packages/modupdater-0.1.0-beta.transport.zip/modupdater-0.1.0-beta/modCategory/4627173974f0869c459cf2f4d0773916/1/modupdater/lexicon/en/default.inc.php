<?php
include_once 'setting.inc.php';

$_lang['modupdater'] = 'MODX Updater';
$_lang['modupdater_menu_desc'] = 'Update MODX version';
$_lang['modupdater_intro_msg'] = 'Update MODX version';
$_lang['modupdater_export_start'] = 'Start updating';
