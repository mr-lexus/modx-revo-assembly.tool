<?php
include_once 'setting.inc.php';

$_lang['modupdater'] = 'Обновление MODX';
$_lang['modupdater_menu_desc'] = 'Дополнение для обновления версии MODX';
$_lang['modupdater_intro_msg'] = 'После нажатия кнопки «Обновить», будет скачен скрипт для обновления и запущена установка.';
$_lang['modupdater_export_start'] = 'Обновить';
