<?php
$hook->setRedirectUrl('http://modx.com/');
return true;