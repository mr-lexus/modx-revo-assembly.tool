<?php
require_once (dirname(dirname(__FILE__)) . '/vproute.class.php');
class vpRoute_mysql extends vpRoute {}