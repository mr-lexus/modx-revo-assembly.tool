--------------------
virtualpage
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------

Virtual page for MODx Revolution.

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/vgrish/virtualpage/issues