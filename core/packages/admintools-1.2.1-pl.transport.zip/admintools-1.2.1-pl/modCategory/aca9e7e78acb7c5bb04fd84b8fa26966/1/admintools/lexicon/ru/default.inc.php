<?php

$_lang['admintools'] = 'AdminTools';
$_lang['admintools_show_favorites'] = 'Показать избранное';
$_lang['admintools_show_all'] = 'Показать все';
$_lang['admintools_add_to_favorites'] = 'Добавить в избранное';
$_lang['admintools_remove_from_favorites'] = 'Удалить из избранного';

$_lang['admintools_open'] = 'Открыть элемент';
$_lang['admintools_close'] = 'Закрыть';
$_lang['admintools_clear'] = 'Очистить список';
$_lang['admintools_last_edited'] = 'Список измененных элементов';
$_lang['admintools_item_remove'] = 'Удалить запись';
$_lang['admintools_items_remove'] = 'Удалить записи';
$_lang['admintools_item_remove_confirm'] = 'Вы уверены, что хотите удалить запись?';
$_lang['admintools_item_remove_all_confirm'] = 'Вы уверены, что хотите очистить список?';
$_lang['admintools_name'] = 'Наименование';
$_lang['admintools_type'] = 'Тип элемента';
$_lang['admintools_date'] = 'Дата изменения';
$_lang['admintools_user'] = 'Пользователь';

$_lang['admintools_element_nf'] = 'Элемент не найден!';