<?php
/*
$_lang['admintools_prop_limit'] = 'Ограничение вывода Предметов на странице.';
$_lang['admintools_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['admintools_prop_sortBy'] = 'Поле сортировки.';
$_lang['admintools_prop_sortDir'] = 'Направление сортировки.';
$_lang['admintools_prop_tpl'] = 'Чанк оформления каждого ряда Предметов.';
$_lang['admintools_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
*/