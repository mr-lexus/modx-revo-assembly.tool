<?php

$_lang['area_admintools_main'] = 'Main';
$_lang['setting_admintools_favorites_icon'] = 'Favorite element icon';
$_lang['setting_admintools_favorites_icon_desc'] = 'An icon to replace standart icon. For example, "icon-star".';
$_lang['setting_admintools_remember_system_settings'] = 'Remember system settings filters';
$_lang['setting_admintools_remember_system_settings_desc'] = 'Restores the filter values on the next loading the system settings page.';
$_lang['setting_admintools_check_elements_permissions'] = 'Check elements permissions';
$_lang['setting_admintools_check_elements_permissions_desc'] = 'Switches on the elements permissions. It slows loading the elements tree and consumes more memory.';
$_lang['setting_admintools_enable_elements_log'] = 'Enable log of elements';
$_lang['setting_admintools_enable_elements_log_desc'] = 'Add button to the elements tree toolbar that opens recently edited elements.';
