<?php

$_lang['area_modtelegram_main'] = 'Основные';
$_lang['area_modtelegram_pusher'] = 'Pusher';

$_lang['setting_modtelegram_api_url'] = 'Url Telegram api';
$_lang['setting_modtelegram_api_url_desc'] = 'Url для отправки запроса к Url Telegram api';

$_lang['setting_modtelegram_api_key'] = 'Ключ Telegram api';
$_lang['setting_modtelegram_api_key_desc'] = 'Ключ для отправки запроса к Telegram api';

$_lang['setting_modtelegram_web_hook_url'] = 'Url webhook';
$_lang['setting_modtelegram_web_hook_url_desc'] = 'Url для получения ответов от Telegram api';

$_lang['setting_modtelegram_web_hook_action'] = 'Действия webhook';
$_lang['setting_modtelegram_web_hook_action_desc'] = 'Список доступных действий webhook';

$_lang['setting_modtelegram_action_password'] = 'Пароль';
$_lang['setting_modtelegram_action_password_desc'] = 'Пароль подтверждения действий';

$_lang['setting_modtelegram_tpl_user_info'] = 'Чанк пользователя';
$_lang['setting_modtelegram_tpl_user_info_desc'] = 'Чанк информации о пользователе';


$_lang['setting_modtelegram_pusher_active'] = 'Pusher';
$_lang['setting_modtelegram_pusher_active_desc'] = 'Включить / Выключить Pusher';

$_lang['setting_modtelegram_pusher_id'] = 'Pusher id';
$_lang['setting_modtelegram_pusher_id_desc'] = 'Pusher id';

$_lang['setting_modtelegram_pusher_key'] = 'Pusher key';
$_lang['setting_modtelegram_pusher_key_desc'] = 'Pusher key';

$_lang['setting_modtelegram_pusher_secret'] = 'Pusher secret';
$_lang['setting_modtelegram_pusher_secret_desc'] = 'Pusher secret';

$_lang['setting_modtelegram_pusher_cluster'] = 'Pusher cluster';
$_lang['setting_modtelegram_pusher_cluster_desc'] = 'Pusher cluster';

$_lang['setting_modtelegram_pusher_encrypted'] = 'Pusher encrypted';
$_lang['setting_modtelegram_pusher_encrypted_desc'] = 'Pusher encrypted';



