<?php
require_once (dirname(dirname(__FILE__)) . '/modtelegrammanager.class.php');
class modTelegramManager_mysql extends modTelegramManager {}