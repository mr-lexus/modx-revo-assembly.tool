<?php

/* Errors */

$_lang['modtelegram_err_system'] = 'Системная ошибка';
$_lang['modtelegram_err_unknown'] = 'Неизвестная ошибка';
$_lang['modtelegram_err_value'] = 'Неверное значение';
$_lang['modtelegram_err_lock'] = 'Эта операция заблокирована';
$_lang['modtelegram_err_ns'] = 'Это поле обязательно';
$_lang['modtelegram_err_ae'] = 'Это поле должно быть уникально';
$_lang['modtelegram_err_object_exists'] = 'Объект уже существует';

$_lang['modtelegram_err_action_ns'] = 'Не указан ключ (action)';
$_lang['modtelegram_err_form_key_ns'] = 'Не указан ключ формы (form_key)';
$_lang['modtelegram_err_properties_ns'] = 'Не указаны свойства (properties)';
$_lang['modtelegram_err_action_un'] = 'Неизвестный ключ (action)';
$_lang['modtelegram_err_chunk_ns'] = 'Не указан чанк для обработки';

$_lang['modtelegram_err_file_type'] = 'Неправильный тип файла';
$_lang['modtelegram_err_file_extension'] = 'Неправильное расширение файла';
$_lang['modtelegram_err_file_size'] = 'Файл больше допустимого размера';
$_lang['modtelegram_err_file_ns'] = 'Ошибка обработки указанного файла';

