<?php

$_lang['modtelegram_prop_actions'] = 'Список доступных действий, через запятую';
$_lang['modtelegram_prop_helper'] = 'Параметры помощника';
$_lang['modtelegram_prop_frontendCss'] = 'Файл с css стилями для подключения на фронтенд.';
$_lang['modtelegram_prop_frontendJs'] = 'Файл с javascript для подключения на фронтенде.';
$_lang['modtelegram_prop_frontendLexicon'] = 'Лексиконы для подключения на фронтенде.';
$_lang['modtelegram_prop_actionUrl'] = 'Коннектор для обработки ajax запросов.';

