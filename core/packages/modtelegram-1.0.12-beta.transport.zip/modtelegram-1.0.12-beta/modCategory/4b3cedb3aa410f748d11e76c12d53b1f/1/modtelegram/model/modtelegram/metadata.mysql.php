<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'modTelegramUser',
    1 => 'modTelegramManager',
    2 => 'modTelegramChat',
    3 => 'modTelegramMessage',
  ),
);