<?php
require_once (dirname(dirname(__FILE__)) . '/modtelegrammessage.class.php');
class modTelegramMessage_mysql extends modTelegramMessage {}