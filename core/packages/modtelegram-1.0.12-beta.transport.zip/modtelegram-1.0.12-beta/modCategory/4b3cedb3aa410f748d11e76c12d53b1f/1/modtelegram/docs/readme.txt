--------------------
modTelegram
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------