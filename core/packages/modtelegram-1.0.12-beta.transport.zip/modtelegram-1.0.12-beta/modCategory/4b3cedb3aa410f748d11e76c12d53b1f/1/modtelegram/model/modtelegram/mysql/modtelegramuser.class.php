<?php
require_once (dirname(dirname(__FILE__)) . '/modtelegramuser.class.php');
class modTelegramUser_mysql extends modTelegramUser {}