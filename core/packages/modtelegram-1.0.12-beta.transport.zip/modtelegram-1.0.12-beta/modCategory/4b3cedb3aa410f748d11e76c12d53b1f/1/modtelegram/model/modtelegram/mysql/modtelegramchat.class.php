<?php
require_once (dirname(dirname(__FILE__)) . '/modtelegramchat.class.php');
class modTelegramChat_mysql extends modTelegramChat {}