<?php
/**
 * pdoPage English Lexicon Entries for pdoTools
 *
 * @package pdotools
 * @subpackage lexicon
 * @language en
 */
$_lang['pdopage_first'] = 'First';
$_lang['pdopage_last'] = 'Last';
$_lang['pdopage_more'] = 'Load more';
$_lang['pdopage_page'] = 'page';
$_lang['pdopage_from'] = 'from';