modxSite
=====================================================

This MODX Extra automatically installing most popular MODX-packages on your MODX-site
